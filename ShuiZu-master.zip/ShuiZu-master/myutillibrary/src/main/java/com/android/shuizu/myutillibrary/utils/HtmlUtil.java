package com.android.shuizu.myutillibrary.utils;

/**
 * YuMeiChaYin
 * Created by 蔡雨峰 on 2017/11/20.
 */

public class HtmlUtil {
    public static String getNewContent(String htmltext){

//        Document doc= Jsoup.parse(htmltext);
//        Elements elements=doc.getElementsByTag("img");
//        for (Element element : elements) {
//            element.attr("width","100%").attr("height","auto");
//        }
//
//        return doc.toString();
        return "";
    }
}
