package com.android.kevin.shuizu.ui

import android.os.Bundle
import com.android.kevin.shuizu.R
import com.android.shuizu.myutillibrary.MyBaseActivity

/**
 * ChaYin
 * Created by ${蔡雨峰} on 2018/10/21/021.
 */
class NetworkActivity : MyBaseActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network)
    }
}